#include <stdio.h>
#include <stdlib.h>

int fibonacci(int n, int x){ 
  int f1=1, f2=1, soma, r=0;
  for(int i=3;i<=x;i++){
    soma=f1+f2;
    f1=f2;
    f2=soma;
    if(f2==n) r=1;
  }
  return r;
}

int main(){
  int n, r, m;

  printf("Insira um numero inteiro positivo: ");
  scanf("%d", &n);

  printf("Insira ate qual valor deseja calcular a fib: ");
  scanf("%d", &m);

  r=fibonacci(n, m);
  if (r==1) printf("numero faz parte da sequencia");
  if (r==0) printf("numero nao faz parte da sequencia");
  return 0;
}