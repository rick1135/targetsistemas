#include <stdio.h>
#include <string.h>

char invertaStr(char c[100], int t){
    if(t==0) return 1;
    else {
        printf("%c", c[t-1]);
        invertaStr(c,t-1);
    }
}

int main()
{
    char word[100], res;
    int tam;
    printf("Insira uma palavra: ");
    gets(word);
    tam=strlen(word);
    res=invertaStr(word,tam);
    return 0;
}