#include <stdio.h>
#include <stdlib.h>

int main(){
  int superior=0;
  float vetor[30], maior=0, menor=9999, media=0;

  for(int i=0;i<30;i++){
    printf("insira o valor do faturamento do dia %d da distribuidora: ", i+1);
    scanf("%f", &vetor[i]);
    if(vetor[i]>maior) maior=vetor[i];
    if(vetor[i]<menor) menor=vetor[i];
    media=media+vetor[i];
  }

  media=media/30;

  for(int i=0;i<30;i++){
    if(vetor[i]>media) superior++;
  }
  
  printf("O dia em que ocorreu o menor faturamento do mes: %.2f\n", menor);
  printf("O dia em que ocorreu o maior faturamento do mes: %.2f\n", maior);
  printf("Numero de dias no mes em que o valor de faturamento diario foi superior a media mensal: %d\n", superior);

  return 0;
}