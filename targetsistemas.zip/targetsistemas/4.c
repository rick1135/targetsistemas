#include <stdio.h>
#include <stdlib.h>

int main(){
  float SP=67836.43, RJ=36678.66, MG=29229.88, ES=27165.48, Outros=19849.53, total;

  total=SP+RJ+MG+ES+Outros;

  printf("Total do faturamento mensal da distribuidora: %.2f\n", total);
  printf("Porcentagem do faturamento do estado de SP em relacao ao total foi de: %.2f porcento\n", (SP*100)/total);
  printf("Porcentagem do faturamento do estado de RJ em relacao ao total foi de: %.2f porcento\n", (RJ*100)/total);
  printf("Porcentagem do faturamento do estado de MG em relacao ao total foi de: %.2f porcento\n", (MG*100)/total);
  printf("Porcentagem do faturamento do estado de ES em relacao ao total foi de: %.2f porcento\n", (ES*100)/total);
  printf("Porcentagem do faturamento do outros estados em relacao ao total foi de: %.2f porcento\n", (Outros*100)/total);

  return 0;
}